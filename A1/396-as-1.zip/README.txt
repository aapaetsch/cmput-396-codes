Name: Aidan Paetsch
Consulted Resources: https://crypto.interactive-maths.com/columnar-transposition-cipher.html
- Textbook 

a1p1.py has function encryptMessage(key, message)
a1p2.py has function decryptMessage(key, message)
both are my modified columnar-transposition-cipher encryption/decryption

In my a1p3.py I use the library itertools, this appears to already be on the lab machines from my testing. 
