Name: Aidan Paetsch
Resources: Http://inventwithpython.com/hacking

I use functions from util.py in my assignment. 
- No one else was consulted for this assignment.

