Name: Aidan Paetsch


Supporting files are:
- a1p2.py
- detectEnglish.py
- cryptomath.py
- caesar.py
- affineCipher.py
- ciphers.txt
- dictionary.txt
- simpleSubCipher.py
- wordPatterns.py
- makeWordPatterns.py

For Problem 1 run modifiedGeneralHacker.py
	This requires the library itertools, if the lab machine does not have
	this, please run pip3 -install itertools, however it should already
	have this library
	
	The output is put into a file called deciphered.txt if you run this
	program, however my results are in the a4.txt file.
	

For Problem 2:
	The main function in this one runs the example from the a4.pdf and
	checks if the outputs from encryptMessage and decryptMessage matches
	it.
	
	The encryptMessage and decryptMessage functions should function as
	required without needing to run main(). 
	
	

For Problem 3:
	The function in modifiedSimpleSubHacker.py hackSimpleSub takes in the
	cipher text and returns the decoded text. 
