Name: Aidan Paetsch
alice.py only requires bob.py to run

