Name: Aidan Paetsch

preproc.py requires vigenere to run

vigenereIC takes the function getNthSubkeysLetters from vigenereHacker
The function is basically unedited except for now containing     NONLETTERS_PATTERN = re.compile('[^A-Z]') that was initially outside of it. This is done to reduce the amount of files needed to submit. 