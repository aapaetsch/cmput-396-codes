Name: Aidan Paetsch
Resources: http://inventwithpython.com/hacking
Consulted with: Johnson Lou 


For a3p2.py The main function is for testing purposes, it simply validates it
against the example. Please run the lcg function directly to get the list of
the first 10 digits as specified.  

a3p4.py requires cryptomath.py to run, as it is used to find the modular
inversion. 
For a3p4.py I adapt the decrypt from affine.py to solve for A 
The equation for solving for A is adapted from affine.py
Again the main function here is for testing. To get the [A,B] list call
the crack_lcg function. 
