Name: Aidan Paetsch

Files created from fileFreqAnalysis are put in the directory of fileFreqAnalysis

The Results folder contains my output files from fileFreqAnalysis as [start of file name]_plain, from simpleSubHacker as [start of file name]_plain_hackSimpleSub, and from the online solver as [start of file]_plain_online

The online solver seems to give slightly different results each time a decipherment is run. 

Table results were calculated using subEval, comparing them to the correct plain text file character by character

